let screen=document.getElementById("display");
let buttons=document.querySelectorAll(".calculator button");
let screenValue="";
let history=[];
for (item of buttons) {
    item.addEventListener("click", (e) => {
      let buttonText = e.target.innerText;
  
      if (buttonText === "=") {
        let result;
        try {
          result = eval(screenValue);
          addToHistory(screenValue + " = " + result);
        } catch (error) {
          result = "Expression error";
        }
        screen.value = result;
        screenValue = "";
      } else if (buttonText === "C") {
        screenValue = "";
        screen.value = screenValue;
      } else {
        screenValue += buttonText;
        screen.value = screenValue;
      }
    });
  }
function addToHistory(item){
    history.push(item);
    if(history.length>10){
        history.shift();
    }
    displayHistory();
}
function displayHistory(){
    let historyList=document.getElementById("history");
    historyList.innerHTML="";
    for(let i=history.length-1;i>=0;i--){
        let listItem=document.createElement("li");
        listItem.innerText=history[i];
        historyList.appendChild(listItem);
    }
}