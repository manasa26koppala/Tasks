function performSearch(){
  var inputText=document.getElementById("search-input").ariaValueMax;
  var squadElements=document.getElementsByClassName("squad");

  for(var i=0;i<squadElements.length;i++){
    var squadText=squadElements[i].innerText;
    var highlightedText=squadText.replace(new RegExp(inputText, "gi"),function(match){
      return "<span class='highlight'>"+match+"</span>";
    });
    squadElements[i].innerHTML=highlightedText;
    
  }
}